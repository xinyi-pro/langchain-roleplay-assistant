#!/usr/bin/env python
import os
import sys
from dotenv import load_dotenv

load_dotenv()

api_key = os.getenv('DEEPSEEK_API_KEY')
model = os.getenv('DEEPSEEK_MODEL', 'deepseek-chat')
base_url = os.getenv('DEEPSEEK_API_BASE', 'https://api.deepseek.com')

print('='*60)
print('Direct API Test (without LangChain)')
print('='*60)
print(f'API Key: {api_key[:10]}...{api_key[-5:]}')
print(f'Base URL: {base_url}')
print(f'Model: {model}')
print('='*60)

try:
    from openai import OpenAI
    print('✓ OpenAI client imported')

    client = OpenAI(
        api_key=api_key,
        base_url=base_url
    )
    print('✓ Client initialized')

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "你是一个友好的助手"},
            {"role": "user", "content": "请说'测试成功'"}
        ],
        temperature=0.7
    )

    result = response.choices[0].message.content
    print(f'✓ Response: {result}')
    print('='*60)
    print('SUCCESS!')
    print('='*60)

except Exception as e:
    print('='*60)
    print(f'ERROR: {type(e).__name__}')
    print(f'Message: {e}')
    print('='*60)
    import traceback
    traceback.print_exc()
    sys.exit(1)