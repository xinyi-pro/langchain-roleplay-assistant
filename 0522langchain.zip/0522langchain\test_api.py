#!/usr/bin/env python
import requests
import json

print('Testing Chat API...')
print('='*60)

url = 'http://localhost:8000/chat'
data = {
    'user_id': 'test_user',
    'role': 'tech_teacher',
    'message': '你好，请介绍一下Python'
}

try:
    response = requests.post(url, json=data)
    print(f'Status Code: {response.status_code}')
    print('='*60)

    if response.status_code == 200:
        result = response.json()
        print(f'Role: {result["role"]}')
        print('Response:')
        print(result["response"])
        print('='*60)
        print('SUCCESS!')
    else:
        print(f'Error: {response.text}')
        print('='*60)

except Exception as e:
    print(f'Request failed: {e}')
    print('='*60)