#!/usr/bin/env python
import os
import sys

# 确保路径正确
sys.path.insert(0, os.path.dirname(__file__))

from langchain_openai import ChatOpenAI
from dotenv import load_dotenv

load_dotenv()

api_key = os.getenv('DEEPSEEK_API_KEY')
base_url = os.getenv('DEEPSEEK_API_BASE')
model = os.getenv('DEEPSEEK_MODEL', 'deepseek-chat')

print('='*50)
print('Testing DeepSeek API Configuration')
print('='*50)
print(f'API Key: {api_key[:10]}...{api_key[-5:]}')
print(f'Base URL: {base_url}')
print(f'Model: {model}')
print('='*50)

try:
    llm = ChatOpenAI(
        model=model,
        api_key=api_key,
        base_url=base_url
    )
    print('LLM initialized successfully')

    response = llm.invoke('请说"测试成功"')
    print(f'Response: {response.content}')
    print('='*50)
    print('TEST PASSED!')
except Exception as e:
    print('='*50)
    print(f'ERROR: {type(e).__name__}')
    print(f'Message: {str(e)}')
    print('='*50)
    sys.exit(1)