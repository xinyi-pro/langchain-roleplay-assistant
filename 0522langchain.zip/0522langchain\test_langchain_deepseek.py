#!/usr/bin/env python
print("Testing langchain_deepseek import...")

try:
    from langchain_deepseek import ChatDeepSeek
    print("✓ langchain_deepseek imported successfully")
    print("✓ ChatDeepSeek class available")
except Exception as e:
    print(f"✗ Import failed: {e}")
    import traceback
    traceback.print_exc()
    exit(1)

print("\nTesting DeepSeek API with langchain-deepseek...")
import os
from dotenv import load_dotenv

load_dotenv()

api_key = os.getenv('DEEPSEEK_API_KEY')
model = os.getenv('DEEPSEEK_MODEL', 'deepseek-chat')

print(f"API Key: {api_key[:10]}...{api_key[-5:]}")
print(f"Model: {model}")

try:
    llm = ChatDeepSeek(
        model=model,
        temperature=0.7,
        api_key=api_key
    )
    print("✓ LLM initialized")

    response = llm.invoke('请说"测试成功"')
    print(f"✓ Response: {response.content}")
    print("\n" + "="*50)
    print("SUCCESS! DeepSeek API is working!")
    print("="*50)
except Exception as e:
    print(f"✗ API call failed: {e}")
    import traceback
    traceback.print_exc()
    exit(1)