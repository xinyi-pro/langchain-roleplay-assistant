#!/usr/bin/env python
print("Step 1: Basic imports")
try:
    import os
    print("  ✓ os imported")
except Exception as e:
    print(f"  ✗ os import failed: {e}")
    exit(1)

try:
    from dotenv import load_dotenv
    print("  ✓ dotenv imported")
except Exception as e:
    print(f"  ✗ dotenv import failed: {e}")
    exit(1)

try:
    from langchain_openai import ChatOpenAI
    print("  ✓ langchain_openai imported")
except Exception as e:
    print(f"  ✗ langchain_openai import failed: {e}")
    exit(1)

print("\nStep 2: Load environment variables")
load_dotenv()
api_key = os.getenv('DEEPSEEK_API_KEY')
base_url = os.getenv('DEEPSEEK_API_BASE')
model = os.getenv('DEEPSEEK_MODEL', 'deepseek-chat')

print(f"  API Key: {api_key}")
print(f"  Base URL: {base_url}")
print(f"  Model: {model}")

if not api_key:
    print("  ✗ DEEPSEEK_API_KEY not found!")
    exit(1)

print("\nStep 3: Initialize LLM")
try:
    llm = ChatOpenAI(
        model=model,
        api_key=api_key,
        base_url=base_url
    )
    print("  ✓ LLM initialized")
except Exception as e:
    print(f"  ✗ LLM initialization failed: {e}")
    exit(1)

print("\nStep 4: Test API call")
try:
    response = llm.invoke('请说"测试成功"')
    print(f"  ✓ Response: {response.content}")
except Exception as e:
    print(f"  ✗ API call failed: {e}")
    exit(1)

print("\n" + "="*50)
print("ALL TESTS PASSED!")
print("="*50)