#!/usr/bin/env python
"""测试脚本"""
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

def test_personas():
    """测试人物模块"""
    print("测试知名人物模块...")
    from backend.personas import get_persona_summary, PERSONAS
    
    print(f"✓ 共有 {len(PERSONAS)} 个知名人物")
    
    personas = get_persona_summary()
    print(f"✓ 人物摘要获取成功：{len(personas)} 个人物")
    
    for p in personas:
        print(f"  - {p['id']}: {p['name']}")
    
    return True

def test_server_import():
    """测试服务器导入"""
    print("\n测试服务器导入...")
    
    try:
        from backend.server import app
        print("✓ 服务器导入成功")
        print(f"✓ 应用标题: {app.title}")
        print(f"✓ 应用版本: {app.version}")
        return True
    except Exception as e:
        print(f"✗ 服务器导入失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    test_personas()
    test_server_import()
