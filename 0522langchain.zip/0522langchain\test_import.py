#!/usr/bin/env python
import sys
print(f"Python version: {sys.version}")
print(f"Python executable: {sys.executable}")
print("\nTrying to import langchain_openai...")

try:
    import langchain_openai
    print("Success! langchain_openai imported")
    print(f"Version: {langchain_openai.__version__}")
except ImportError as e:
    print(f"ImportError: {e}")
    import traceback
    traceback.print_exc()
except Exception as e:
    print(f"Error: {type(e).__name__}: {e}")
    import traceback
    traceback.print_exc()
